"use client";
import { motion } from "framer-motion";
import "./../styles/home.css";

export default function Hero() {
  return (
    <section className="hero">
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
      >
        <h1>Dreams <span>Created</span></h1>
        <p>Turn your passion into a creative career in Animation & VFX.</p>
        <button className="btn">Talk to us</button>
      </motion.div>
    </section>
  );
}