"use client";
import { motion } from "framer-motion";
import "./../styles/home.css";

export default function Courses() {
  const courses = [
    "3D Animation",
    "VFX & Editing",
    "Graphic Design",
    "AR/VR",
  ];

  return (
    <section className="courses">
      <h2>A Career You Love</h2>

      <div className="course-list">
        {courses.map((c, i) => (
          <motion.div
            key={i}
            className="course-card"
            whileHover={{ y: -10 }}
          >
            {c}
          </motion.div>
        ))}
      </div>
    </section>
  );
}