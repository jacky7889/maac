"use client";
import { motion } from "framer-motion";
import { ShieldCheck, Award, Sparkles } from "lucide-react";
import "./../styles/home.css";

export default function Features() {
  const data = [
    { icon: <ShieldCheck />, title: "Certified", text: "Industry certified courses" },
    { icon: <Award />, title: "Quality", text: "High quality training" },
    { icon: <Sparkles />, title: "Creative", text: "Boost your creativity" },
  ];

  return (
    <section className="features">
      {data.map((item, i) => (
        <motion.div
          key={i}
          className="card"
          whileHover={{ scale: 1.05 }}
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
        >
          {item.icon}
          <h3>{item.title}</h3>
          <p>{item.text}</p>
        </motion.div>
      ))}
    </section>
  );
}